# Python-CSGO-Glow-ESP
just update offsets from haze dumper
you can use this as it is or add to it.
